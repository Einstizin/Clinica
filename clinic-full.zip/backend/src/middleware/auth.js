const jwt=require('jsonwebtoken');
module.exports=(req,res,next)=>{
const t=req.headers.authorization;if(!t)return res.sendStatus(401);
try{req.user=jwt.verify(t,process.env.JWT_SECRET);next();}catch{res.sendStatus(403);}
};